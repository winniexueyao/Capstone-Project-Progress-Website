// 元数据配置文件
export const metadata = {
    title: "项目管理系统",
    description: "毕设项目进度展示与管理系统",
  };
  